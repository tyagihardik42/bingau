from setuptools import setup

setup(name = "bingau",
      version = '0.1',
      description = 'Gaussian & Binomial distributions',
      packages = ['bingau'],
      author = 'Hardik Tyagi',
      author_email = 'tyagi.hardik42@yahoo.com',
      zip_safe = False)
